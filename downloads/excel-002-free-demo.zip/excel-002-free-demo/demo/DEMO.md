# Margin Control — free demo

This is a **free sample**, not the paid product. It exists so you can see the exact
output format before you install anything or pay anything.

## What is in this bundle

| File | What it is |
| --- | --- |
| `demo/demo.csv` | The 10-SKU demo dataset, with a baseline period |
| `demo/expected-report.md` | The report the Margin Control tool produced from that dataset |
| `preview/preview.html` | The same report rendered as a static page — open it in any browser, no runtime needed |

## What is not in this bundle, and why

The **tool itself** (the CLI, its source and its tests) is not here. This bundle is the
sample output only. The paid archive contains the tool, its test suite, three datasets
and a per-file SHA256 manifest.

`run-demo.sh` from the paid archive is deliberately not included here: it needs the
tool to run, and shipping it without the tool would only produce an error.

## The one result worth looking at

Open `demo/expected-report.md`. On the bundled dataset the weighted margin is
**40.88%** and there is exactly one breach: `SKU-1007` (HDMI Adapter) at a **14.29%**
margin, down **30.71 pp** against the baseline period, with a minimum price of
**4.80** to reach the 25% target.

That row is real output from the tool on this dataset, not an example written for a
sales page.

## Requirements if you later run the tool

- Node.js 20 or newer
- No network access, no account, no subscription, no paid dependencies
- Reads CSV, not `.xlsx`

## Integrity

This archive carries a per-file `SHA256SUMS` manifest. After unpacking, run
`sha256sum -c SHA256SUMS` in the folder.